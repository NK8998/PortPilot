// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently
//

#pragma once

#include <gtest/gtest.h>
#include <gmock/gmock.h>
