void foo()
{
}